﻿namespace Homework_7.GA.Mutation
{
    public interface IMutation
    {
        public void Mutate(Individual individual);
    }
}