﻿namespace Homework_7.GA.Crossover
{
    public interface ICrossover
    {
        public Individual Cross(Individual a, Individual b);
    }
}